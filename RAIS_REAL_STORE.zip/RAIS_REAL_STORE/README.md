# **RAIS_REAL STORE**

Website premium **jual beli akun game, jasa joki, dan top up semua game**.  
Semua produk HD, aman & cepat.

---

## Fitur Utama
- Jual akun: ML, FF, eFootball  
- Joki: ML Gendong  
- Top Up semua game sesuai harga standar  
- Filter kategori & search produk  
- Pembayaran: WhatsApp, Dana, GoPay, SeaBank  
- Marquee info: transaksi aman & cepat  
- Social media: TikTok & Facebook  

---

## Screenshot
![Header RAIS_REAL STORE](images/HEADER_HD.jpg)
![Produk & Top Up](images/ML_HD_PLACEHOLDER.jpg)

---

## Lisensi
- Web untuk **keperluan pribadi / bisnis RAIS_REAL_STORE**  
- **Dilarang menyalin / jual ulang** tanpa izin  

> Dibuat dengan ❤️ oleh RAIS_REAL_STORE